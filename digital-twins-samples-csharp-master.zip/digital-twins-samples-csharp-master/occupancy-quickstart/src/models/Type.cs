﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Azure.DigitalTwins.Samples.Models
{
    public class SensorType
    {
        public int Id { get; set; }
        public string SpaceId { get; set; }
        public string Category { get; set; }
        public string Name { get; set; }
        public bool disabled { get; set; }
        public int logicalOrder { get; set; }
        public string friendlyName { get; set; }
        public string description { get; set; }
    }
}
